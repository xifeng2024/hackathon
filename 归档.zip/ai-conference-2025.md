---
title: "Global AI Conference 2025"
startDate: 2025-10-20
endDate: 2025-10-22
organizer: "Future Tech Org"
location:
  city: "San Francisco"
  country: "USA"
  online: false
url: "https://example.com/aiconf"
tags: ["AI", "Machine Learning", "Data Science"]
language: "English"
image: "/images/ai-event.png"
featured: true
eventType: ["AI", "Big Data"]
region: "Americas"
category: "Conference"
---
