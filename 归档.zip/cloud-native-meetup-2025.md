---
title: "Cloud Native Meetup 2025"
startDate: 2025-12-05
endDate: 2025-12-05
organizer: "Cloud Native Computing Foundation"
location:
  city: "Amsterdam"
  country: "Netherlands"
  online: false
url: "https://example.com/cloudnative"
tags: ["Cloud Native", "Kubernetes", "Docker", "Microservices"]
language: "English"
image: "/images/ai-event.png"
featured: false
eventType: ["Cloud"]
region: "Europe"
category: "Meetup"
---

Monthly meetup for cloud native enthusiasts and practitioners.