---
title: "Gaming & Metaverse Expo 2026"
startDate: 2026-11-18
endDate: 2026-11-20
organizer: "Virtual Worlds Association"
location:
  city: "Los Angeles"
  country: "USA"
  online: false
url: "https://example.com/gaming-metaverse-2026"
tags: ["Gaming", "VR", "Metaverse", "AR"]
language: "English"
image: "/images/ai-event.png"
featured: false
eventType: ["Gaming"]
region: "Americas"
category: "Expo"
---

Experience the future of gaming and virtual worlds at the most immersive expo featuring VR, AR, and metaverse technologies.