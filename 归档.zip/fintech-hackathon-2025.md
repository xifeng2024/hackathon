---
title: "Fintech Hackathon 2025"
startDate: 2025-11-20
endDate: 2025-11-22
organizer: "Innovation Bank"
location:
  city: "Sydney"
  country: "Australia"
  online: false
url: "https://example.com/fintechhack"
tags: ["Fintech", "Hackathon", "Innovation", "Startups"]
language: "English"
image: "/images/ai-event.png"
featured: true
eventType: ["Fintech"]
region: "Other"
category: "Hackathon"
---

48-hour hackathon focused on creating innovative fintech solutions.